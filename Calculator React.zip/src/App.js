
import './App.css';

import Calcutator from './Component/Calcutator';

function App() {
  return (
    <div className="App">
     <Calcutator />
    
    </div>
  );
}

export default App;
